/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class hmckoclss {
    
   private String nom_empleado;
   private String usarioinnn;

    public String getNom_empleado() {
        return nom_empleado;
    }

    public String getUsarioinnn() {
        return usarioinnn;
    }

    public hmckoclss(String nom_empleado, String usarioinnn) {
        this.nom_empleado = nom_empleado;
        this.usarioinnn = usarioinnn;
    }

    public String mostrartab() {
        return "hmckoclss{" + "nom_empleado=" + nom_empleado + ", usarioinnn=" + usarioinnn + '}';
    }

    
    
    
}
